package exam1;

/**
 * Created by kkang on 10/13/2016.
 */
public interface MotorlessInter {
    public int hasPedals();
    public int hasHnadlebars();
    public int hasStand();
}
