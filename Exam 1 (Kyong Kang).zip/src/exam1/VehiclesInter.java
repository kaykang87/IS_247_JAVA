
package exam1;

public interface VehiclesInter
{
    public void hasWheels();
    public void hasEngine();

}
